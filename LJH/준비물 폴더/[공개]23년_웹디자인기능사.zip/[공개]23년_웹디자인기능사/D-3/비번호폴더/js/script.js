$(function(){

    // 레이어 팝업------------------------------------------------------------------
    $("#layer_popup").hide();
    $(".tab_content:first").click(function(){
        $("#layer_popup").show();
    });
    $("#layer_popup button").click(function(){
        $("#layer_popup").hide();
    });



    // 탭메뉴------------------------------------------------------------------
    $(".tab_content").hide();
    $(".tab_content:first").show()
    $(".tab_title li a:first").addClass("active");

    $(".tab_title li a").click(function(){
        $(".tab_title li a").removeClass("active");
        $(this).addClass("active");
        $(".tab_content").hide();
        var activeTab = $(this).attr("href");
        $(activeTab).show();
        return false;
    });




    // 페이드인/아웃 슬라이드------------------------------------------------------------------

    // 세팅작업
    $("#main_slide>ul>li").hide();
    $("#main_slide>ul>li:first").show();

    var currentIndex = 0;
    // 인덱스번호를 통해 순서대로 선택할 수 있게끔 돌리기 위해 만든 변수. 첫번째 아이템인 0을 먼저 저장
    var slide = $("#main_slide>ul>li");
    // 슬라이드의 리스트들을 담아놓은 변수. 배열 형태로 여러개가 한꺼번에 담긴다.
    var slideLength = $("#main_slide>ul>li").length;
    // 리스트의 개수를 담아놓은 변수. 추후 리스트 개수가 늘어나거나 줄어들어도 개수가 유동적으로 담긴다. 현재 3개.


    setInterval(function(){

        if(currentIndex < slideLength - 1) {
        // 1회전  0     <    3-1 = 2     true => currentIndex = 1
        // 2회전  1     <    3-1 = 2     true => currentIndex = 2
        // 3회전  2     <    3-1 = 2     false => currentIndex = 0
        // 0부터 시작해 슬라이드의 개수보다 1을 뺀 값(2)보다 작을때까지 currentIndex변수에 1씩 증가
            currentIndex++;
        } else {
            currentIndex = 0;
        }

        slide.eq(currentIndex).siblings().fadeOut();
        // 리스트의 현재 인덱스번호를 제외한 나머지 형제들을 페이드아웃

        slide.eq(currentIndex).fadeIn();
        // 리스트의 현재 인덱스번호만 페이드인

    }, 3000);



    // 드롭다운 메뉴------------------------------------------------------------------
    $(".main_menu").hover(function(){
        $(".sub_menu,#menu_bg").stop().fadeIn();
        // $("#menu_bg").stop().fadeIn();
    }, function(){
        $(".sub_menu,#menu_bg").stop().fadeOut();
        // $("#menu_bg").stop().fadeOut();
    });
    

});